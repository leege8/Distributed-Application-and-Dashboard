/**
 * Project 4
 * Task 1 and 2
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 * This program demonstrate a simple class Emoji with the following instance variables
 * name: name of the Emoji
 * category: high level category of the Emoji
 * group: which group the Emoji belongs to
 * htmlCode: a unique html code associated with each Emoji
 * unicode: a unicode associated with each Emoji
 */

package ds.edu.project4;
import java.util.ArrayList;
import java.util.Random;

public class Emoji {
    String name;
    String category;
    String group;
    ArrayList<String> htmlCode;
    ArrayList<String> unicode;

    //default constructor of Emoji
    public Emoji() {
        name = "";
        category = "";
        group = "";
        htmlCode = new ArrayList<>();
        unicode = new ArrayList<>();
    }
    //list of getters
    public String getHtmlCode() {
        Random rand = new Random();
        int randomNum = rand.nextInt((htmlCode.size()));
        return htmlCode.get(randomNum);
    }

    public String getName() {
        return name;
    }

}
