/**
 * Project 4
 * Task 1 and 2
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 * This program was executed first to display view "activity_emoji_main"
 * which allows the user to choose:
 * 1. select category of emoji and get an emoji
 * 2. type a search word of emoji and get an emoji
 * 3. ask the system to randomly generate an emoji
 * after the user makes the choices, they will be re-directed to
 * view "activity_emoji_one", "activity_emoji_two", and "activity_emoji_three"
 * respectively
 */

package ds.edu.project4;
// import required packages
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

//declare three instance variables that allows the user to make choice
public class EmojiActivityMain extends AppCompatActivity {
    // define the global variable
    // Add button Move to Activity
    Button choose_button;
    Button search_button;
    Button random_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoji_main);
        choose_button = (Button) findViewById(R.id.first_activity_button);
        search_button = (Button) findViewById(R.id.second_activity_button);
        random_button = (Button) findViewById(R.id.third_activity_button);

        // choose_button add clicklistener: redirect to the next view based on user's choice
        // on how to get the Emoji
        // next view in this case: choose category of emoji to get an emoji
        choose_button.setOnClickListener(v -> {
            Intent intent = new Intent(EmojiActivityMain.this, EmojiActivityOne.class);
            // start the activity connect to the specified class
            startActivity(intent);
        });

        // choose_button add clicklistener: redirect to the next view based on user's choice
        // on how to get the Emoji
        // next view in this case: search for a term and get the emoji
        search_button.setOnClickListener(v -> {
            Intent intent = new Intent(EmojiActivityMain.this, EmojiActivityTwo.class);
            // start the activity connect to the specified class
            startActivity(intent);
        });

        // choose_button add clicklistener: redirect to the next view based on user's choice
        // on how to get the Emoji
        // next view in this case: ask the system to randomly generate an emoji
        random_button.setOnClickListener(v -> {
            Intent intent = new Intent(EmojiActivityMain.this, EmojiActivityThree.class);
            // start the activity connect to the specified class
            startActivity(intent);
        });
    }
}