/**
 * Project 4
 * Task 1 and 2
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 * This program allows the users to choose a category and will
 * automatically generate an emoji related to that category
 * choices can be made repeatedly
 * also, users are allowed to go back to the main view using previous_button
 * where they can re-choose from the three buttons on how to
 * get an Emoji
 */

package ds.edu.project4;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// declare three instance variables
public class EmojiActivityOne extends AppCompatActivity {
    Button previous_button;
    String searchTerm = "";
    EmojiActivityOne me = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoji_one);

        final EmojiActivityOne ma = this;

        // four radio buttons where each is related to an Emoji
        RadioButton radioActivity = (RadioButton) findViewById(R.id.radio_activity);
        RadioButton radioNature = (RadioButton) findViewById(R.id.radio_nature);
        RadioButton radioPeople = (RadioButton) findViewById(R.id.radio_people);
        RadioButton radioTravel = (RadioButton) findViewById(R.id.radio_travel);
        // submit button: generate the emoji
        // previous button: go back to the main view
        Button submit = (Button)findViewById(R.id.submit);
        previous_button = (Button) findViewById(R.id.returnbutton);

        // previous_button add clicklistener
        previous_button.setOnClickListener(v -> {
            // Intents are objects of the android.content.Intent type. Your code can send them to the Android system defining
            // the components you are targeting. Intent to start an activity called oneActivity with the following code
            Intent intent = new Intent(EmojiActivityOne.this, EmojiActivityMain.class);
            // start the activity connect to the specified class
            startActivity(intent);
        });

        // Add a listener to the submit button
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View viewParam) {

                if (radioActivity.isChecked()) {
                    searchTerm = radioActivity.getText().toString();
                } else if (radioNature.isChecked()) {
                    searchTerm = radioNature.getText().toString();
                } else if (radioPeople.isChecked()) {
                    searchTerm = radioPeople.getText().toString();
                } else if (radioTravel.isChecked()) {
                    searchTerm = radioTravel.getText().toString();
                }

                // print the value of selected category
                Toast.makeText(getApplicationContext(), searchTerm, Toast.LENGTH_LONG).show();
                EmojiModel em = new EmojiModel();
                setProgressValue();
                em.search(searchTerm, me, ma);
            }
        });
    }

    // this method will eventually display the emoji to user
    // based on the response from server after making the http request
    // it also handles the situation when there is no response related to
    // the search term user chooses
    // this method will be called in the EmojiModel
    public void emojiReady(String pictureURL) {
        TextView textView = (TextView) this.findViewById(R.id.TextView);
        TextView responseView = (TextView) this.findViewById(R.id.responseView);

        if (pictureURL.equals("NA")){
            System.out.println("No picture");
            responseView.setText("Sorry! The Emoji for " + searchTerm + " is not available");
            textView.setText(Html.fromHtml("<p>&#128546;</p>", Html.FROM_HTML_MODE_COMPACT));
            textView.setVisibility(View.VISIBLE);
        } else {
            responseView.setText("Here is an emoji for " + searchTerm);
            textView.setText(Html.fromHtml("<p>"+ pictureURL+"</p>", Html.FROM_HTML_MODE_COMPACT));
            System.out.println("picture");
            textView.setVisibility(View.VISIBLE);
        }
        textView.invalidate();
    }

    // this method display an animation indicating progress when the system is preparing
    // generating the Emoji based on user input
    // reference: https://developer.android.com/reference/android/widget/ProgressBar
    public void setProgressValue() {
        ProgressBar pgsBar = (ProgressBar) findViewById(R.id.p_Bar);
        Handler hdlr = new Handler(Looper.getMainLooper());
        pgsBar.setProgress(0);
        pgsBar.setVisibility(View.VISIBLE);

        new Thread(new Runnable() {
            int i = pgsBar.getProgress();
            public void run() {
                while (i < 100) {
                    i += 1;
                    // Update the progress bar and display the current value in text view
                    hdlr.post(new Runnable() {
                        public void run() { pgsBar.setProgress(i); }
                    });
                    try {
                        // Sleep for 100 milliseconds to show the progress slowly.
                        Thread.sleep(8);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
}