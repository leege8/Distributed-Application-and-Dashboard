/**
 * Project 4
 * Task 1 and 2
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 * This program will automatically generate an emoji and no user input is
 * required. The input is basically: "random".
 * choices can be made repeatedly
 * also, users are allowed to go back to the main view using previous_button
 * where they can re-choose from the three buttons on how to
 * get an Emoji
 */

package ds.edu.project4;
//import required packages
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

// extend from EmojiActivityOne to inherit all the methods and properties
// so that we don't have to re-write the method
public class EmojiActivityThree extends EmojiActivityOne{

    public EmojiActivityThree() {
        super();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoji_three);
        final EmojiActivityThree ma = this;
        Button generate = (Button)findViewById(R.id.generate);
        previous_button = (Button) findViewById(R.id.returnbutton);

        // previous_button add clicklistener
        previous_button.setOnClickListener(v -> {
            Intent intent = new Intent(EmojiActivityThree.this, EmojiActivityMain.class);
            // start the activity connect to the specified class
            startActivity(intent);
        });

        // Add a listener to the generate button
        generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View viewParam) {
                searchTerm = "random";
                Toast.makeText(getApplicationContext(), searchTerm, Toast.LENGTH_LONG).show();
                EmojiModel em = new EmojiModel();
                setProgressValue();
                em.search(searchTerm, me, ma);
            }
        });
    }
}