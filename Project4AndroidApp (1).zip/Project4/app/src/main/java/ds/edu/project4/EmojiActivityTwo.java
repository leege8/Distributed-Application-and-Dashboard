/**
 * Project 4
 * Task 1 and 2
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 * This program allows the users to type in a term and will
 * automatically generate an emoji related to that search term
 * choices can be made repeatedly
 * also, users are allowed to go back to the main view using previous_button
 * where they can re-choose from the three buttons on how to
 * get an Emoji
 */

package ds.edu.project4;

// import required packages
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// extend from EmojiActivityOne to inherit all the methods and properties
// so that we don't have to re-write the method
public class EmojiActivityTwo extends EmojiActivityOne {

    public EmojiActivityTwo() {
        super();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoji_two);
        final EmojiActivityTwo ma = this;
        Button research = (Button)findViewById(R.id.research);
        previous_button = (Button) findViewById(R.id.returnbutton);

        // previous_button add clicklistener
        previous_button.setOnClickListener(v -> {
            Intent intent = new Intent(EmojiActivityTwo.this, EmojiActivityMain.class);
            // start the activity connect to the specified class
            startActivity(intent);
        });

        // Add a listener to the research button
        research.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View viewParam) {
                searchTerm = ((EditText)findViewById(R.id.searchTerm)).getText().toString();
                Toast.makeText(getApplicationContext(), searchTerm, Toast.LENGTH_LONG).show();
                EmojiModel em = new EmojiModel();
                setProgressValue();
                em.search(searchTerm, me, ma);
            }
        });
    }
}