/**
 * Project 4
 * Task 1 and 2
 *
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 *
 * This program demonstrate a simple class EmojiModel that fetch Emoji in
 * Json representation generated from the API EmojiHub. Different Emoji will
 * be randomly fetched based on UserInput, specifically user will choose one
 * of the Emoji category from the menu in Main program.
 *
 * The EmojiModel has three instance variables:
 * emojiURL: html code associated with the Emoji
 * emojiName: name of the emoji
 * emojiGroup: group of the emoji
 * ip: for call back purpose
 * searchTerm: user input in the application
 * picture: returns the hashcode of emoji
 */

package ds.edu.project4;
//import required packages
import android.app.Activity;
import android.os.Build;
import androidx.annotation.RequiresApi;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

//initialize the instance variables
public class EmojiModel {
    String emojiURL;
    String emojiName;
    String emojiGroup;
    EmojiActivityOne ip = null;
    String searchTerm = null;
    String picture = null;

    //assign variable to instance variables
    public EmojiModel(){
        emojiURL = "";
        emojiName = "";
        emojiGroup = "";
    }
    public void search(String searchTerm, Activity activity, EmojiActivityOne ip) {
        this.ip = ip;
        this.searchTerm = searchTerm;
        new BackgroundTask(activity).execute();
    }

    // reuse some approaches from interesting pictures
    private class BackgroundTask {
        private Activity activity; // The UI thread
        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }
        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {
                    try {
                        doInBackground();
                    } catch (UnsupportedEncodingException e) {
                        throw new RuntimeException(e);
                    }
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }
        private void execute(){
            // There could be more setup here, which is why startBackground is not called directly
            startBackground();
        }
        private void doInBackground() throws UnsupportedEncodingException {
            picture = doEmojiSearch(searchTerm);
        }
        public void onPostExecute() {
            ip.emojiReady(picture);
        }

        //This method uses the EmojiHub API and userInput (category of the emoji) to search for
        //emojiURL, emojiName, and emojiGroup
        public String doEmojiSearch(String searchTag) throws UnsupportedEncodingException {
            //must replace all the space with "-" in userInput
            searchTag = URLEncoder.encode(searchTag.replace(" ", "-").toLowerCase(), "UTF-8");

            String EmojiURL = "";

            //EmojiURL = "http://10.0.2.2:8080/Project4WebServer-1.0-SNAPSHOT/getEmoji/" + searchTag;
            EmojiURL = "https://leege8-jubilant-carnival-qr5x6764g54f9xgx-8080.preview.app.github.dev/getEmoji/" + searchTag;

            // Fetch the page by calling function fetch(), this returns an Emoji object
            Emoji emoji = new Emoji();
            emoji = fetch(EmojiURL);

            if (emoji == null) {
                // handling the case when there is no output related to user searched term
                return "NA";
            } else {
                return emoji.getHtmlCode();
            }
        }

        //This method fetch the Emoji in Json representation using parameter url
        // then convert the Json representation in String to Emoji class
        // eventually return the Emoji object
        @RequiresApi(api = Build.VERSION_CODES.P)
        public Emoji fetch(String urlString) {
            String response = "";
            try {
                URL url = new URL(urlString);
                /*
                 * Create an HttpURLConnection.  This is useful for setting headers
                 * and for getting the path of the resource that is returned (which
                 * may be different than the URL above if redirected).
                 * HttpsURLConnection (with an "s") can be used if required by the site.
                 */
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    // Read all the text returned by the server
                    BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                    String str;
                    // Read each line of "in" until done, adding each to "response"
                    while ((str = in.readLine()) != null) {
                        // str is one line of text readLine() strips newline characters
                        response += str;
                    }
                    in.close();
                } else {
                    return null;
                }
            } catch (IOException e) {
                System.out.println("An exception occurred!");
                return null;
            }
            Gson gson = new Gson();
            Emoji emoji = gson.fromJson(response, Emoji.class);
            return emoji;
        }
    }
}