/**
 * Project 4
 * Task 1 and 2
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 * This program demonstrate a simple class Emoji with the following instance variables
 * name: name of the Emoji
 * category: high level category of the Emoji
 * group: which group the Emoji belongs to
 * htmlCode: a unique html code associated with each Emoji
 * unicode: a unicode associated with each Emoji
 */

package ds.project4webserver;
//import required packages
import java.util.ArrayList;
import java.util.Random;
public class Emoji {
    String name;
    String chosenHtmlCode;
    String category;
    String group;
    ArrayList<String> htmlCode;
    ArrayList<String> unicode;


    //default constructor of Emoji
    public Emoji() {
        name = "";
        category = "";
        group = "";
        htmlCode = new ArrayList<>();
        unicode = new ArrayList<>();
        chosenHtmlCode = "";

    }
    //list of getters
    // note by searching the category name of emoji
    // there may be more than one emoji related to it
    // randomly choose one and store the chosen emoji in
    // variable chosenHtmlCode
    public String getHtmlCode() {
        Random rand = new Random();
        int randomNum = rand.nextInt((htmlCode.size()));
        chosenHtmlCode = htmlCode.get(randomNum);
        return chosenHtmlCode;
    }
    public String getChosenHtmlCode(){
        return chosenHtmlCode;
    }

    public String getName() {
        return name;
    }
    public String getGroup() {
        return group;
    }
    public String getCategory() {
        return category;
    }
    public ArrayList<String> getUnicode() {
        return unicode;
    }

}
