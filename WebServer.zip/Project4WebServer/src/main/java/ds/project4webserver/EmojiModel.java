/**
 * Project 4
 * Task 1 and 2
 *
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 *
 * This program demonstrate a simple class EmojiModel that fetch Emoji in
 * Json representation generated from the API EmojiHub. Different Emoji will
 * be randomly fetched based on UserInput, specifically user will choose one
 * of the Emoji category from the menu in Main program.
 *
 * The EmojiModel has three instance variables:
 * emojiURL: html code associated with the Emoji
 * emojiName: name of the emoji
 * emojiGroup: group of the emoji
 * These three instance variables will be displayed in the web application through EmojiServlet
 */

package ds.project4webserver;

//import required packages
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

//initialize the instance variables
public class EmojiModel {
    String emojiURL;
    String emojiName;
    String emojiGroup;

    //assign variable to instance variables
    public EmojiModel(){
        emojiURL = "";
        emojiName = "";
        emojiGroup = "";
    }

    // this method returns the Emoji object in Json format in string
    public String toJsonString(Emoji emoji) {
        Gson gson = new Gson();
        String messageToSend = gson.toJson(emoji);
        return messageToSend;
    }
    //This method uses the EmojiHub API and userInput (category of the emoji) to search for
    //emojiURL, emojiName, and emojiGroup
    public Emoji doEmojiSearch(String searchTag) throws UnsupportedEncodingException {
        //must replace all the space with "-" in userInput
        searchTag = URLEncoder.encode(searchTag.replace(" ","-"), "UTF-8");
        String EmojiURL = "";
        if (searchTag.contains("random")) {
           EmojiURL = "https://emojihub.yurace.pro/api/random";
        } else {
            // Create a URL (combination of API and userInput) for the page to be screen scraped
            EmojiURL = "https://emojihub.yurace.pro/api/random/category/" + searchTag;
        }
        // Fetch the page by calling function fetch(), this returns an Emoji object
        Emoji emoji = fetch(EmojiURL);
        emojiURL = emoji.getHtmlCode();
        emojiName = emoji.getName();
        emojiGroup = emoji.getGroup();
        return emoji;
    }

    //This method fetch the Emoji in Json representation using parameter url
    // then convert the Json representation in String to Emoji class
    // eventually return the Emoji object
    public Emoji fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                // Read all the text returned by the server
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String str;
                // Read each line of "in" until done, adding each to "response"
                while ((str = in.readLine()) != null) {
                    // str is one line of text readLine() strips newline characters
                    response += str;
                }
                in.close();
            }
        } catch (IOException e) {
            System.out.println("An exception occurred!");
        }
        Gson gson = new Gson();
        Emoji emoji = gson.fromJson(response,Emoji.class);
        return emoji;
    }
}