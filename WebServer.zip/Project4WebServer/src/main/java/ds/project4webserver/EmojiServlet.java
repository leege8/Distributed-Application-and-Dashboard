/**
 * Project 4
 * Task 1 and 2
 *
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 *
 * This program demonstrate a simple class EmojiServer for web application purpose
 * the EmojiServer is an important component of request-response programming model
 * based on the user request (client), the browser (server) will send the corresponding response.
 * Additionally, doctype is implemented to allow different scales of applications (phone, tablets)
 * used together with POJO
 */

package ds.project4webserver;

//import required packages
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.util.*;

// set up the urlPattern
@WebServlet(name = "EmojiServlet", urlPatterns = {"/getEmoji/*"})
public class EmojiServlet extends HttpServlet {
    EmojiModel emojiModel = null; // initialize emojiModel

    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {emojiModel = new EmojiModel(); }

    // this method capture the request (userInput) and send it to server
    // also set up the appropriate DOCTYPE based on user's current device
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // initiate MongoDB object
        MongoDB mongoDB = new MongoDB();
        // create the collection by calling method createMongoDB
        try{
            mongoDB.createMongoDB();
            System.out.println();
        } catch (Exception e) {
            System.out.println("Connection error!");
        }

        // read each documents stored in MongoDB, including user input, response, and logging data
        mongoDB.readDocument();
        // call method makeHtmlTable to return a table in html format
        String htmlGroup = makeHtmlTable(mongoDB.SortMap(mongoDB.getGroupMap()));
        // call method makeHtmlTable to return a table in html format
        String htmlCategory = makeHtmlTable(mongoDB.SortMap(mongoDB.getCategoryMap()));
        // set the attribute values in the response jsp file
        request.setAttribute("htmlGroup", htmlGroup);
        request.setAttribute("htmlCategory", htmlCategory);
        request.setAttribute("GroupNum", mongoDB.getGroupMap().size());
        request.setAttribute("CategoryNum", mongoDB.getCategoryMap().size());
        request.setAttribute("EmojiNum", mongoDB.getLogArrayList().size());
        // indicate the last time the application was used, this is part of analytics feature
        try {
            request.setAttribute("LastSearchTime", mongoDB.getDate().toString());
        } catch (ParseException e) {
            request.setAttribute("LastSearchTime", "Not Available");
            throw new RuntimeException(e);
        }
        // call method createHtmlTableFromList to return a table in html format
        String htmlTable = createHtmlTableFromList(mongoDB.getLogArrayList());
        request.setAttribute("logTable", htmlTable);

        //capture search request by calling method getParameter
        String pathInfo = request.getPathInfo();
        String search = null;
        if (pathInfo != null) {
            search = pathInfo.substring(1).split("/")[0];
        }

        /*
         * Check if the search parameter is present.
         * If not, then give the user instructions and prompt for a search string.
         * If there is a search parameter, then do the search and return the result.
         */
        if (search != null) {
            long startTime = System.currentTimeMillis();


            // write response to the http request from Android application
            // this will not dispatch to a jsp file
            // directly write output by passing the json data in string
            Emoji emoji = emojiModel.doEmojiSearch(search);
            String ipAddress = request.getRemoteAddr();
            String userAgent = request.getHeader("User-Agent");

            String emojiJsonString = emojiModel.toJsonString(emoji);
            request.getAttribute("doctype");
            response.setContentType("text/html");
            PrintWriter output = response.getWriter();
            output.println(emojiJsonString);
            System.out.println(emojiJsonString);

            long endTime = System.currentTimeMillis();
            long latency = endTime - startTime;
            // each request from the Android application and response by the server
            // will be documented in the MongoDB by calling writeDocument method
            mongoDB.writeDocument(emoji, ipAddress, userAgent, latency, search);

        } else {
            // when running the server, the dashboard with analytics feature and
            // logging data will be prompted
            // dashboard stored in response.jsp, forward the view
            request.getRequestDispatcher("response.jsp").forward(request, response);
        }
    }

    //this method take an arraylist as the parameter and return an HTML table
    //in string format. This will be used to display the search frequency of
    //variables group and category in the dashboard.
    //reference: https://www.w3schools.com/html/
    public String makeHtmlTable(List<Map.Entry<String, Integer>> arrayList) {

        StringBuilder htmlBuilder = new StringBuilder();
        // specify the column names directly in the response.jsp file.
        htmlBuilder.append("<tbody>");
        for (Map.Entry<String, Integer> entry : arrayList.subList(0, Math.min(5, arrayList.size()))) {
            htmlBuilder.append("<tr>");
            htmlBuilder.append("<td>").append(entry.getKey()).append("</td>");
            htmlBuilder.append("<td>").append(entry.getValue()).append("</td>");
            htmlBuilder.append("</tr>");
        }
        htmlBuilder.append("</tbody>");
        String html = htmlBuilder.toString();
        return html;
    }

    // this method returns a table in html format in string
    // with the parameter: an array list, where the list of logMessages are stored
    // call this method to dispaly the logging data in the dashboard
    //reference: https://www.w3schools.com/html/
    public static String createHtmlTableFromList(ArrayList<?> list) {
        StringBuilder tableBuilder = new StringBuilder();
        if (list != null && list.size() > 0) {
            // Get field names from the first object in the list
            Field[] fields = list.get(0).getClass().getDeclaredFields();

            // Build table headers row
            tableBuilder.append("<table>\n<tr>");
            for (Field field : fields) {
                tableBuilder.append("<th>").append(field.getName().toUpperCase()).append("</th>");
            }
            tableBuilder.append("</tr>\n");

            // Build table data rows
            for (Object obj : list) {
                tableBuilder.append("<tr>");
                for (Field field : fields) {
                    field.setAccessible(true);
                    try {
                        tableBuilder.append("<td>").append(field.get(obj)).append("</td>");
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
                tableBuilder.append("</tr>\n");
            }
            tableBuilder.append("</table>");
        }
        return tableBuilder.toString();
    }
}
