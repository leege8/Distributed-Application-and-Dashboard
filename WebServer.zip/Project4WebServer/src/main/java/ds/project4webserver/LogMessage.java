/**
 * Project 4
 * Task 1 and 2
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 * This program demonstrate a simple class LogMessage with the following instance variables
 * index: series of integer starting from 1, 2, 3, ....
 * date: user searched date and time
 * input: user input
 * htmlCode: a unique html code associated with each Emoji
 * name: name of the emoji
 * category: category of the emoji
 * group: group of the emoji
 * device: device the user used to perform searching
 * latency: does the user get instant results?
 * ip: ip address of the user
 */

package ds.project4webserver;

//declare variables
public class LogMessage {
    long index;
    String date;
    String input;
    String htmlCode;
    String name;
    String category;
    String group;
    String Device;
    String latency;
    String ipAddress;

    // initiate variables
    public LogMessage(){
        index= 0;
        date="";
        input="";
        name="";
        category="";
        group="";
        Device="";
        latency="";
        ipAddress="";
        htmlCode = "";
    }

    //list of getters and settings
    public void setIndex(long index) {
        this.index = index;
    }
    public void setHtmlCode(String htmlCode) {
        this.htmlCode = htmlCode;
    }
    public void setInput(String input) {
        this.input = input;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public void setGroup(String group) {
        this.group = group;
    }
    public void setDevice(String device) {
        Device = device;
    }
    public void setLatency(String latency) {
        this.latency = latency;
    }
    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getCategory() {
        return category;
    }
    public String getGroup() {
        return group;
    }

}
