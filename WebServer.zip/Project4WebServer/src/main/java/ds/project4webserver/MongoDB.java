/**
 * Project 4
 * Task 1 and 2
 *
 * Author: Lee Ge
 * UID: Yge2
 * Email: Yge2@andrew.cmu.edu
 * Last Modified: April 9, 2023
 *
 * This program demonstrate a simple class MongoDB that read documents from and write documents to MongoDB
 * The MongoDB cluster is set up with the following information
 * cluster name: Project4Cluster
 * passwords: 13813659155qQ
 * region clusters:
 * ac-p3oagra-shard-00-01.j81zkga.mongodb.net:27017
 * ac-p3oagra-shard-00-02.j81zkga.mongodb.net:27017
 * ac-p3oagra-shard-00-00.j81zkga.mongodb.net:27017
 *
 * DataBase Name: EmojiDatabase
 * Collection Name: EmojiCollection
 *
 * The class MongoDB has three instance variables:
 * connectionURL: to access the MongoDB
 * databaseName: which database to connect to in MongoDB
 * collectionName: which collection in the database to connect to in MongoDB
 *
 * references: Connection Guid (Java)
 * https://www.mongodb.com/docs/drivers/java/sync/v4.3/fundamentals/connection/
 */

package ds.project4webserver;
//import required packages

import com.mongodb.*;
import com.mongodb.client.*;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

//initialize the three instance variables
public class MongoDB {
    static final String connectionURL = "mongodb://yge2:13813659155q@ac-p3oagra-shard-00-01.j81zkga.mongodb.net:27017,ac-p3oagra-shard-00-02.j81zkga.mongodb.net:27017,ac-p3oagra-shard-00-00.j81zkga.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
    static String databaseName;
    static String collectionName;

    Map<String, Integer> categoryMap;

    Map<String, Integer> groupMap;

    ArrayList<String> dateList;

    ArrayList<LogMessage> logArrayList;


    // assign values to instance variables databaseName and collectName
    public MongoDB() {
        databaseName = "EmojiDatabase";
        collectionName = "EmojiCollection";
        logArrayList = new ArrayList<>();
        groupMap = new HashMap<>();
        categoryMap = new HashMap<>();
        dateList = new ArrayList<>();
    }

    public Map<String, Integer> getCategoryMap() {
        return categoryMap;
    }

    public Map<String, Integer> getGroupMap() {
        return groupMap;
    }

    public ArrayList<LogMessage> getLogArrayList() {
        return logArrayList;
    }

    //getter method
    public static String getDatabaseName() {
        return databaseName;
    }

    // This methods establish connection with MongoDB by connectionURL
    // a new mongoClient will be returned
    private MongoClient ConnectMongoDB() {
        ConnectionString connectionString = new ConnectionString(connectionURL);
        MongoClientSettings settings = MongoClientSettings.builder().applyConnectionString(connectionString).serverApi(ServerApi.builder().version(ServerApiVersion.V1).build()).build();
        //mongoClient defines the initial connection to the MongoDB server
        MongoClient mongoClient = MongoClients.create(settings);
        return mongoClient;
    }

    public Date getDate() throws ParseException {
        ArrayList<Date> dateListFormated = new ArrayList<>();
        if (dateList.size()==0) {
            return Calendar.getInstance().getTime();
        }
        for (String str: dateList) {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = formatter.parse(str);
            dateListFormated.add(date);
        }

        Date latestDate = null;

        for (Date date : dateListFormated) {
            if (latestDate == null || date.after(latestDate)) {
                latestDate = date;
            }
        }
        return latestDate;
    }

    // This method read every document in the collection of database in MongoDB server
    // additionally, it compute the number of category and number searched by the users.
    public void readDocument() {
        // call method ConnectMongoDB to get mongoClient and establish connect with MongoDB server
        MongoClient mongoClient = ConnectMongoDB();
        // get the specific database in MongoDB server by name
        // if the database does not exist in the MongoDB server, it will be automatically created
        MongoDatabase database = mongoClient.getDatabase(databaseName);
        // get the specific collection in the database in MongoDB server by collectionName
        MongoCollection<Document> collection = database.getCollection(collectionName);
        // if there is zero document stored in the collection, return no document found
        if (collection.countDocuments() == 0) {
            System.out.println("There is no document found in collection " + collectionName + " in database " + databaseName);
        }
        //otherwise, retrieving the documents
        //how to read all document in MongoDB through JAVA:
        //https://www.tutorialspoint.com/how-to-retrieve-all-the-documents-from-a-mongodb-collection-using-java
        FindIterable<Document> iterDoc = collection.find(); // invoke find method
        ArrayList<String> groupList = new ArrayList<>();
        ArrayList<String> categoryList = new ArrayList<>();

        for (Document document: iterDoc) {
            LogMessage logMessage = new LogMessage();
            //retrieve the data and place it in LogMessage class
            logMessage.setName(document.get("name").toString());
            logMessage.setCategory(document.get("category").toString());
            logMessage.setGroup(document.get("group").toString());
            logMessage.setDevice(document.get("device").toString());
            //logMessage.setInput(document.get("search").toString());
            logMessage.setLatency(document.get("latency").toString());
            logMessage.setIpAddress(document.get("ip").toString());
            logMessage.setDate(document.get("Date").toString());
            logMessage.setHtmlCode(document.get("htmlCode").toString());
            logMessage.setInput(document.get("Input").toString());
            logMessage.setIndex(Long.parseLong(document.get("index").toString()));
            // add group of emoji to an array list, preparing for computation of frequency
            groupList.add(document.get("group").toString());
            // do the same for category list, this is part of the analytics feature
            categoryList.add(document.get("category").toString());
            // do the same for user searched date and time, this is part of the analytics feature
            dateList.add((String) document.get("Date"));
            logArrayList.add(logMessage);
        }
        //iterate the loop of logMessage and then loop through each group in the group array list
        // compute the number of searches for each group
        // then stored in hashmap called groupMap
        for (LogMessage logMessage: logArrayList) {
            int i = 0;
            for (String str: groupList) {
                if (logMessage.getGroup().equals(str)) {
                    i++;
                }
            }
            groupMap.put(logMessage.getGroup(), i);
        }
        //do the same process for the category variable
        for (LogMessage logMessage: logArrayList) {
            int i = 0;
            for (String str: categoryList) {
                if (logMessage.getCategory().equals(str)) {
                    i++;
                }
            }
            categoryMap.put(logMessage.getCategory(), i);
        }
    }

    //This method return a sorted list of keys and values by value in descending order
    public List<Map.Entry<String, Integer>> SortMap(Map<String, Integer> attributeMap ) {

        List<Map.Entry<String, Integer>> sortedList = new ArrayList<>(attributeMap.entrySet());
        Collections.sort(sortedList, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        });
        return sortedList;
    }

    //this method create the collection in the specific database
    //note the same collection cannot be created twice
    //thus, if the connection exist, then write the data to MongoDB server
    //if the connection does not exist, then create the connection first and then write data to MongoDB server
    public void createMongoDB() {
        MongoClient mongoClient = ConnectMongoDB();
        System.out.println("Successfully establish connect with MongoDB server");
        System.out.println("Connecting to database " + getDatabaseName());
        // get the database by name
        MongoDatabase database = mongoClient.getDatabase(databaseName);
        // put all collections in the array list called collectionNames
        List<String> collectionNames = database.listCollectionNames().into(new ArrayList<>());
        // if the collection exists in the array list then there is no need to re-create it.
        if (collectionNames.contains(collectionName)) {
            System.out.println("Collection exits in database "+ databaseName +", start uploading data to collection " + collectionNames);
        }
        else {
            System.out.println("Collection doesn't exit in database "+ databaseName + ", creating new collection " + collectionName + " ....");
            database.createCollection("EmojiCollection");
            System.out.println("Successfully created collection " + collectionName +" in " + databaseName);
        }
    }

    //this method write data to mongoDB server from Emoji object
    //the Emoji object is used as the parameter
    //create bson objection by using Document and set the unique objectID for each document
    //append other features "name, category, group, htmlCode, unicode by get method of Emoji
    //lastly, insert the document to mongoDB server
    public void writeDocument(Emoji emoji, String ipAddress, String userAgent, long latency, String search) {
        MongoClient mongoClient = ConnectMongoDB();
        MongoDatabase database = mongoClient.getDatabase(databaseName);
        MongoCollection<Document> collection = database.getCollection(collectionName);
        long index = collection.countDocuments();
        Document newEmoji = new Document("_id", new ObjectId());
        newEmoji.append("index", index+1);
        newEmoji.append("name", emoji.getName());
        newEmoji.append("category", emoji.getCategory());
        newEmoji.append("group", emoji.getGroup());
        newEmoji.append("htmlCode", emoji.getChosenHtmlCode());
        newEmoji.append("unicode", emoji.getUnicode());
        newEmoji.append("ip", ipAddress);
        newEmoji.append("device", userAgent);
        newEmoji.append("latency", String.valueOf(latency)+" milliseconds");
        newEmoji.append("Input", search);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        newEmoji.append("Date", dtf.format(now));

        collection.insertOne(newEmoji);
        System.out.println("Successfully upload the new Emoji " + emoji.getName() + " to MongoDB server!");
    }
}
